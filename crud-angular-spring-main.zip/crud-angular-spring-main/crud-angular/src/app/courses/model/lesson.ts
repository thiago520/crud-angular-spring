export interface Lesson {
  _id: string;
  name: string;
  youtubeUrl: string;
}
